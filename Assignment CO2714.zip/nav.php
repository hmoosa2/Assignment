<a href="Display.php">Display Records </a>
<a href="newuser.php">Add New Record </a>
<a href="login.php">Login </a>
<a href="logout.php">Logout </a>
